list_of_strings = ['Oh', 'look', 'another', 'list', 'of', 'strings']

Print the fourth through the sixth elements of the list using a slice.
