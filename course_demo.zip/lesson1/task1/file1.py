list_of_strings = ['Here', 'is', 'a', 'list', 'of', 'strings']

Print the fourth item in the list

Print the last element of the list
