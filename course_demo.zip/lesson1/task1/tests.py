from test_helper import run_common_tests, failed, passed, get_file_output


def test_file_output():
    output = get_file_output()

    if output[0] != 'list':
        failed("Code did not print 'list'")
    elif output[1] != 'strings':
        failed("Code did not print 'strings'")
    else:
        passed()


if __name__ == '__main__':
    run_common_tests()
    test_file_output()


